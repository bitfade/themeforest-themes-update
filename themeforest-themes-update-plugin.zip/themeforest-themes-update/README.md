Themeforest Themes Update WordPress Plugin
=========================

Install the plugin, then edit wp-config.php and add

```php
// USERNAME = buyer username on Envato
define('THEMEFOREST_USERNAME','USERNAME');

// APIKEY = buyer api key
define('THEMEFOREST_APIKEY','APIKEY');
```


* [Screenshot 1](http://assets.pixelentity.com/github/themeforest-themes-update/updater1.jpg)
* [Screenshot 2](http://assets.pixelentity.com/github/themeforest-themes-update/updater2.jpg)
* [Video](http://www.youtube.com/watch?v=3UNA5AHEFF0)